# Changelog

All notable changes to AutoTPose will be documented here.

## 0.2.0 - 2026-09-06

### Added

- Blender-independent `autotpose_core` data contracts.
- Solver protocol for a future Python or native implementation.
- Architecture documentation defining Blender/core boundaries.
- Compiled-core adoption criteria and future migration plan.
- Standard-library tests for the new contracts.
- Python project metadata for development tooling.

### Changed

- Documented AutoTPose as Python-first and ready for optional compiled layers.
- Expanded contribution guidance for native/core changes.

## 0.1.0 - 2026-09-06

### Added

- Initial open-source release.
- Automatic armature selection.
- Common-name upper-arm detection.
- Geometry and hierarchy fallback detection.
- Forearm detection and straightening.
- Optional application of the generated T-pose as the new rest pose.
